<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1>ИНФОРМАЦИОННЫЕ СИСТЕМЫ И ПРОГРАММИРОВАНИЕ</h1><hr>
                <h2>КУРСЫ</h2>
<form class="row g-3 needs-validation" novalidate>
      <div class="col-md-4">
        <label for="validationCustom04" class="form-label">Уровень образование</label>
        <select class="form-select" id="validationCustom04">
          <option value="">...</option>
        </select>
      </div>
      <div class="col-md-4">
        <label for="validationCustom04" class="form-label">Форма обучения</label>
        <select class="form-select" id="validationCustom04">
          <option value="">...</option>
        </select>
      </div>
    
  </form>
                <div class="table-responsive">

				<!-- Скрипт для пагинации -->
				<script>
				$(document).ready(function () {
					var table = $('#curs').DataTable({
						
					});

				});
				</script>

				<div class="data_table">
					<table id="curs" class="table table-striped" style="width:100%">
						<thead>
							<tr class="text-center">
								<th>Программы </th>
								<th>цена</th>
								<th>g</th>
							</tr>
						</thead>
						<tbody>
                            <tr class="text-center">
                                <td>а</td>
                                <td>1200</td>
                                <td class="text-left"><button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">График курсов</button>

<div class="offcanvas offcanvas-end" style="width: 70%;"  tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasRightLabel">График курсов</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Закрыть"></button>
  </div>
  <div class="offcanvas-body">
    
  <table class="table">
  <thead>
    <tr>
      <th scope="col">Название</th>
      <th scope="col">Дисциплины</th>
      <th scope="col">Дата начала обучения</th>
      <th scope="col">Дата окончания обучения</th>
      <th scope="col">Статус</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>fdfdd</td>
      <td>fdfd</td>
      <td>fdf</td>
      <td>@fdfd</td>
      <td>@fdfd</td>
    </tr>

  </tbody>
</table>
  

  </div>
</div></td>
                            </tr>
						</tbody>
					</table>
				</div>

			</div>


            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js"></script>

</section>